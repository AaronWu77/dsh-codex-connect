# 配置、诊断与恢复

[English](reference.md) | 中文

安装方法与已验证的发布组合见[用户指南](README.zh.md)。本参考文档说明账户行为、可选能力、配置和诊断命令。

## 账户、模型与额度

OAuth 凭据保存在运行 DSH 的主机上，由该主机用于向 OpenAI 认证和发起请求。“模型”卡片和 Codex Connect 设置页共享同一份账户状态；选择账户不是会话级绑定。**管理账户**可以添加、选择或移除账户。浏览器响应只会包含插件生成的账户 key 和脱敏标签，不会暴露 OAuth token 或原始 OpenAI account id。

在 Harness 的常规模型选择器中选择一个 `openai-codex` 模型。所有界面语言均保留模型的规范名称。**更多设置 → 模型** 控制发现列表中显示哪些模型；隐藏模型不会禁用按精确 ID 路由。

每个已保存账户在模型选择器中都有独立路由，因此当前账户不是某个账户时，该账户的模型仍然可以直接选择。当前账户保留 `openai-codex` 路由；其他每个账户分别以 `openai-codex-2`、`openai-codex-3` 等出现。每个账户路由均以 `OpenAI Codex (<显示名称>)` 标注；名称重复时附加不透明账户 key 的后缀，名称为空时回退为 `OpenAI Codex (acct <后缀>)`。每条路由在整个请求期间（包括 token 刷新）都只以自己绑定的账户认证。切换到另一个账户时，`openai-codex` 移交该账户，原当前账户获得一个编号路由；其余账户的编号保持不变。这是模型选择，不是故障切换：Codex Connect 仍不会自动轮换账户，也不会改用其他账户重试被拒绝的请求。

模型选择器在已安装的 `@earendil-works/pi-ai` 记录上叠加实时 Codex 模型目录，并保留原生模型元数据。已安装目录缺少模型时，插件补充 `gpt-6-astra`；只有实时目录或官方 CLI 缓存列出了 `gpt-6-sol`、`gpt-6-luna`，插件才会补充这两个 slug。无论原生还是合成的 `gpt-6.1-sol` 记录，都禁用 Off 和 Minimal。已安装目录缺少 GPT-6.1 记录时，服务器目录中的 Sol 采用已安装 Sol 的工具设置，Terra 借用已安装 Astra 的前沿模型记录。其他缺失的 GPT-6 变体沿用对应 GPT-5.6 变体的工具与推理档位映射；合成记录的名称与上下文上限取自官方目录。可通过 `modelCatalogClientVersion` 将刷新版本设为官方客户端使用的 `0.159.0`。使用 `models` 白名单时须加入对应 ID。目录条目不证明推理权限；账户授权、额度与网络行为仍由 OpenAI 决定。

- 添加账户期间，当前账户仍可继续使用。
- 取消新的授权或等待超时，不会删除任何已有账户，并会关闭已接受的回调连接，包括未完成的 HTTP 请求。取消后，浏览器会一起读取账户标签与额度，再更新显示。待处理授权默认 10 分钟后过期；`oauthTimeoutMs` 接受 1,000–1,800,000 毫秒，并在插件加载时应用。
- 切换账户只影响后续请求。每个请求会在解析认证前固定当前账户，因此并发切换不会混用凭据。如果该账户在认证过程中变得不可用，请求会失败，需要使用所选账户显式重试。
- 额度、搜索、图片生成和自动审查会在 token 刷新期间保持同一请求账户。每次额度响应的用量与账户标签来自同一快照；并发切换时，旧快照可能显示到下次刷新，但不会把它的额度标为另一个账户的。
- 如果还有其他账户，移除当前账户时必须选择替代账户；移除最后一个账户即退出登录；**退出所有账户**会删除本地保存的全部 Codex 凭据。
- 请求被拒绝时，Codex Connect 不会自动轮换账户或进行故障切换。

凭据修改最多等待写锁 20 秒，以便正在进行的 token 刷新完成。等待超时会使操作失败，但不会删除其他写入者的锁或更改已保存的账户。进程崩溃遗留的锁需要操作者确认没有写入者运行后再恢复。

请求认证失败时使用固定提示，不包含上游响应正文或嵌套的提供方异常。刷新失败会保留已保存的凭据。

刷新时收到明确的 OAuth `invalid_grant` 拒绝，会显示重新授权提示。网络故障、超时和服务端错误会保留当前账户并显示额度查询错误，供你重试；不会删除凭据或启动新的登录。

GPT Codex 对话的 Composer 会显示 Fast Mode 与额度：

- **Fast Mode** 只为当前对话请求优先服务（`service_tier: 'priority'`）。默认关闭，也不会更换模型。实际速度和额度消耗取决于服务端，不保证固定提速倍数。
- **额度条**在已保存账户列表就绪后读取非当前账户；非当前账户集合变化时立即更新，不切换当前账户。重复的状态更新共享现有轮询。响应缺少某个账户时显示读取不可用，仅在已有保留期限内保留之前的数字。在已登录时通常每 60 秒刷新一次，只显示服务端实际返回的 `5h` 和 `7d` 窗口，并显示精确剩余百分比与重置时间。`gpt-5.3-codex-spark` 使用独立的 Spark 额度桶。Codex Connect 不会虚构缺失窗口，也不会根据套餐名称隐藏已返回窗口。

其他插件通过 `codexQuota` 客户端服务渲染额度。该服务保留活动账户原有的 `windows` 与 `credits` 字段，并新增 `accounts` 数组，按“活动账户在前、随后为文档顺序”列出每个已登录账户。每个条目包含由不可逆账户 key 生成的短标签（`acct <后缀>`）、窗口、已披露的赠送额度、刷新时间，以及 `unavailable` 标志。只有活动账户来自账户页面自身的轮询；其他已保存账户由 DSH 主机通过 `GET /plugins/dsh-openai-codex/quota` 读取，在有待观察者订阅时约每 60 秒一次。该路由只返回不可逆账户 key 和与状态路由相同的去密用量投影，绝不返回邮箱、token 或提供方账户 id。读取失败的账户会保留最近一次真实数据五分钟，因此单个账户的失败不会清空其他账户的单元格。

<p align="center">
  <img src="https://raw.githubusercontent.com/franksong2702/dsh-codex-connect/main/docs/assets/composer-capabilities.jpg" alt="DeepSeek Harness Composer 中的 Fast Mode 与额度控件" width="820">
</p>

Standard / Fast / Ultrafast 请求档位、请求强度回退值，以及未取消调用的仅原图恢复，见[本地集成参考](local-feature-update.zh.md)。本地审核权限见[自动审查](auto-review.zh.md)。这些设置仍须保存才生效。

## 可选能力

新安装只注册模型提供方，其他能力全部保持关闭：

```yaml
- id: llm-openai-codex
  config:
    enableProxy: false
    enableSearch: false
    enableImageTool: false
    enableImageGeneration: false
    enableAutoReview: false
```

请在 **设置 → Codex Connect** 或 **设置 → 模型 → Openai-Codex → 更多设置** 中编辑这些选项。修改会暂存到点击 **保存更改** 为止。保存会一次提交所有已编辑字段，并保留其他页面对未编辑字段的修改。发生编辑冲突或保存失败时会保留草稿；放弃草稿可重新加载最新设置。注册 Codex 搜索不会修改网页搜索设置选择的路由。

### 模型传输

除非配置了常驻 WebSocket 名额，模型请求都使用有限的 SSE 流。`maxResidentWebSocketSessions`（0–8，默认 2）可在设置卡片的 **网络** 页修改，最多保留同样数量的续接连接，每个活跃会话一条；填 `0` 时不保留常驻连接，每个请求只按 `transport` 决定。名额是权威开关：`llm-openai-codex` profile 配置里的 `transport: sse` 是强制关闭，`transport: auto` 只在名额为 0 时保留此前"每个请求一条独立连接"的请求自有行为。加载时会拒绝 `transport: auto` 与正数名额的组合：将 `maxResidentWebSocketSessions` 设为 0 以保留请求自有连接，或移除 `transport: auto` 以保留常驻续接连接。在常驻续接模式下，标题、压缩、自动审查和子代理请求使用 SSE，不占用名额。

常驻连接通过 PI 的连接级 `previous_response_id` 承载同一会话的连续轮次；请求体保持 `store: false`，因此续接只在这条连接存活期间存在。续接属于尽力而为：当请求体除输入以外的部分与上一轮一致时，PI 只发送输入增量，否则在同一条连接上重发完整对话。提示词缓存仍按 Harness 会话 ID 计算。

最近请求会把每条由会话常驻连接承载、且是该会话唯一在飞请求的请求标为 `增量`（只发新增内容）或 `全量`（发送整段对话而非增量）；重叠的请求不做标注，因为服务端计数器是会话级的；从未使用常驻连接的请求只显示传输方式（`WS` 或 `Stream`）。增量行显示其发送增量的近似字节，全量行显示准备体大小。把鼠标悬停在全量行上会给出首个分歧点：`field:<字段>`、`item:<序号>`、`item:truncated` 或 `response-items`。切换快慢档会改变请求体，因此下一轮会在同一条连接上重发整段对话并标记为 `全量`，而不是继续发送增量。

名额是本地记账，不是服务端上限。新会话会淘汰最久未使用的空闲连接；名额全被占用时，新请求改用 SSE，而不会掐断正在输出的流。握手被拒绝时，使用同一请求已固定的代理和凭据回退 SSE，并按冷却时间重试：账号连接数上限从 15 秒起，反复失败时逐次翻倍至 5 分钟封顶。修改传输、名额、代理、账号或凭据后，会在活动请求结束后关闭常驻连接；卸载和会话销毁也会关闭连接，并清除 PI 的空闲定时器。代理请求失败绝不改走直连。

提供方流开始后不再允许原生回退，而流开始可能早于首个可见文本 Token。API／协议错误、取消和中途断流都不允许直接拼接一次新的 SSE 响应，或执行不完整的工具调用。后续请求重试仍由 Harness 原有恢复机制负责。

卸载时先停止接纳请求、取消活动模型工作，并等待 producer 结束后再释放共享代理资源。PI 1.4 会发起 WebSocket 关闭，但没有可等待的关闭确认 API；producer 完成并不能证明远端关闭握手已结束。提高名额前须在目标运行时验证 Headless 自然退出和卸载。把 `maxResidentWebSocketSessions` 设为 0 或设 `transport: sse` 即可恢复，无需迁移凭据或会话。此设置不改变独立的 HTTP 搜索、图片和自动审查端点。

### 代理

关闭代理或卸载插件时，先给活动代理操作一秒收尾，再销毁本实例的连接池，最多再等待一秒完成。关闭期间拒绝新的代理操作；被中断的请求不会改走直连重试。代理管理器无法强制终止任意应用回调。作用域 dispatcher 会保留至迟到回调结束，防止它们绕过已销毁的代理；无关流量仍使用宿主 dispatcher。

默认使用直连。启用后，不带凭据的 HTTP(S) proxy 只应用于本插件的模型、OAuth、刷新、额度、搜索、图片和自动审查流量。检测只检查标准代理环境变量和文档列出的 loopback 候选地址，不调用模型、不消耗额度，也不保存设置。代理请求失败时，绝不会静默改走直连。加载 Codex Connect 不会替换 Node 的环境代理 dispatcher，因此其他 Harness 请求会继续使用进程已有的代理策略。

### 搜索与图片工具

- `enableSearch: true` 将 Codex 注册为可用搜索提供方。请在 **设置 → 网页搜索与获取** 中选择 OpenAI Codex。如果已明确选用 Codex，请先切换提供方再关闭能力：关闭只会注销 Codex，不会修改 Host 的选择。
- 搜索从认证开始到读完响应共用 30 秒总期限。超过 1 MiB 的响应会被拒绝，失败时会取消尚未读完的响应体。调用方也可以提前取消搜索。
- `enableImageTool: true` 为具备视觉能力的模型注册 `view_image`。远程读取只接受不带凭据的公网 HTTP(S)，并重新检查 DNS 与重定向。
- `enableImageGeneration: true` 注册显式 GPT Image 图片生成与编辑。编辑必须有当前会话有权使用的目标，不会静默变成生成请求。可用性、尺寸和额度仍由账户及服务端控制。
- `imageModelHint` 是“Codex Connect”设置项或 profile config 中的可选设置，按 profile 保存。留空使用 `gpt-image-2`；自定义值接受 1–128 个 ASCII 字母、数字、点、下划线或连字符，且必须以字母或数字开头。保存后会修改后续图片请求的 `model` 字段，仍使用同一固定端点；清空可恢复默认值。生成接受提示词；编辑还必须显式指定来源。这是未经验证的路由提示：服务端可能忽略或拒绝，也不保证返回指定模型。

生成的原文件保存在 `$DSH_HOME/dsh-codex-connect/images/v1`；对话会收到另一份 DSH 附件预览。结果卡片会报告尺寸和文件大小，并可下载任一版本。原文件仅允许所有者访问，下载前会校验完整性，并且只对创建会话及继承了该结果的 fork 开放。关闭能力或卸载插件不会自动删除这些文件。

<p align="center">
  <img src="https://raw.githubusercontent.com/franksong2702/dsh-codex-connect/main/docs/assets/zh/image-generation.png" alt="包含提示词、下载操作与图片详情的 GPT Image 结果" width="780">
</p>

编辑接受一个目标和最多四张参考图，每张参考图须说明用途。来源必须是当前会话或其 fork 继承前缀中已记录的图片附件、保留的原图结果；不接受任意路径、URL 或其他会话的资源 ID。原图和预览是不同选择，仅有预览时编辑需要明确同意。非 Codex 工具结果会持久记录带版本的句柄；Codex 路由从已记录内容派生相同句柄。图片卡片会排入显式的后续指令，不会隐蔽执行编辑。缺少编辑能力时明确拒绝，不会改为重试生成。

### 自动审查

`enableAutoReview: true` 允许 Codex reviewer 在 DSH 策略已经判定需要审批后，评估符合条件的 Harness 审批请求。每个 profile 首次启用时都需要确认，因为有界的近期审批上下文、工具参数、工作目录和待执行动作会发送到 `chatgpt.com`；隐藏推理和已保存凭据不会发送。只有完整、结构化的允许结果才能授权一次执行；歧义、格式错误、传输失败和超时都会交还人工审批。完整决策与重试规则见[自动审查](auto-review.zh.md)。

## 路由与配置

安装 Codex Connect 不会选定默认模型或搜索提供方。请在 **设置 → 网页搜索与获取** 中另行选择搜索提供方，仅在需要时设置默认模型。以下配置启用该能力，并给出可选的默认模型：

```yaml
- id: agent-default-model
  config:
    provider: openai-codex
    model: gpt-5.6-sol

- id: llm-openai-codex
  config:
    enableSearch: true
    searchMode: live
    searchContextSize: medium

```

主要插件选项如下：

| 字段 | 默认值 | 含义 |
|---|---:|---|
| `transport` | 省略 | `sse` 关闭 WebSocket 传输；`auto` 仅在名额为 0 时保留请求自有 WebSocket；`transport: auto` 与正数名额会在加载时被拒绝：将名额设为 0 以保留请求自有连接，或移除 `transport: auto` 以保留常驻续接连接 |
| `maxResidentWebSocketSessions` | `2` | 常驻续接连接数，0–8；填 0 时不保留常驻连接 |
| `models` | 完整目录 | 可见的 Codex model id；空数组隐藏全部条目 |
| `enableNewSessionFastMode` | `false` | 仅为新启动的主对话设置优先服务 |
| `enableNewSubagentFastMode` | `false` | 仅为新启动的子 Agent 对话设置优先服务 |
| `enableProxy` | `false` | Codex Connect 流量是否使用 `proxyUrl` |
| `proxyUrl` | `http://127.0.0.1:7890` | 不带凭据的 HTTP(S) proxy origin；启用前不生效 |
| `contextWindowOverrides` | 无 | 按模型设置客户端上下文预算 |
| `maxTokensOverrides` | 无 | 按模型设置默认最大输出 Tokens |
| `contextWindowMode` | `default` | `default` 使用服务端默认窗口，`extended` 使用其最大值 |
| `modelCatalogClientVersion` | `0.155.0` | 作为模型目录 `client_version` 校验值发送的官方客户端版本 |
| `debugLogPayloadFields` | `false` | 记录每次 Codex 请求的字段名，不记录内容 |
| `enableSearch` | `false` | 注册 Codex 搜索，并在保存时将它选为搜索提供方 |
| `enableImageTool` | `false` | 注册 `view_image` |
| `enableImageGeneration` | `false` | 注册 GPT Image 图片生成 |
| `imageModelHint` | 空字符串 | 可选的未验证图片路由提示；留空保持默认请求 |
| `enableAutoReview` | `false` | 使用 Codex 审查符合条件的审批请求 |
| `searchModel` | `gpt-5.6-sol` | 独立搜索使用的模型 |
| `searchMode` | `cached` | `cached`、`indexed` 或 `live` |
| `searchContextSize` | `medium` | `low`、`medium` 或 `high` |
| `searchMaxOutputTokens` | `10000` | 搜索使用的正整数输出预算 |

`contextWindowOverrides` 修改的是客户端预算，不是 OpenAI 服务端容量。数字覆盖值必须对应已知模型，且不得超过其文档配置上限。将整个字段设为 `null` 可屏蔽继承的全部覆盖值；将单个模型设为 `null` 可恢复其目录默认值，同时保留其他条目。即使模型已从目录移除，单模型重置仍然有效。请为输出和协议开销预留空间，并把更大的数值视为特定部署的实验，不能当作账户权限证据。所有权与持久化规则见 [Alpha 设计](design.zh.md)。

`maxTokensOverrides` 使用相同的地图结构和相同的逐模型上限。每个值会成为 DSH 为该模型上报的请求默认输出上限，以及该模型解析记录中的 `maxTokens`；它不会改变上下文长度，也不代表账户真的能生成这么多。整字段或单个模型设为 `null` 的语义与上文一致。

两个 Fast Mode 默认选项互相独立，仅作用于新启动的 `startup` 会话。加载、恢复或重复通知会话不会重新应用默认值，也不会覆盖手动关闭的选择。两个选项都不改变账号选择。模型预览区分认证、信任、账号移除、宿主不可用、超时和数据格式错误；保留条目会注明是旧数据。目录不可用不会阻止保存与已接受预算无关的设置。尚未采用的代理候选保留为独立草稿，直到采用或放弃。

### 模型目录

插件以活动账户身份、经配置的代理读取 `GET https://chatgpt.com/backend-api/codex/models?client_version=<version>`，并缓存六小时。请求发送 `authorization: Bearer <账户 access token>`、`chatgpt-account-id: <账户 ID>`、`originator: deepseek-harness`，以及携带已存储 `etag` 的 `If-None-Match`；HTTP 304 表示保留缓存值。实时响应提供每个模型的 `context_window`、`max_context_window`、`max_output_tokens`、`supported_reasoning_levels` 和 `service_tiers`。

回退顺序如下，每一层只补充上一层无法提供的部分：

1. 实时读取，缓存在 `$DSH_HOME/dsh-codex-connect-models.json`（仅所有者可读）。
2. 该插件缓存文件，无论实时读取是否成功。
3. 官方 CLI 缓存 `$CODEX_HOME/models_cache.json`（默认 `~/.codex/models_cache.json`），只读取、不写入。
4. 已安装 pi-ai 包内置的目录。

任何一层失败时，每条连续失败最多记录一次日志，绝不向插件激活抛错，也不会移除模型或清空选择器。空或格式错误的实时响应按读取失败处理，因为端点对低于校验值的版本会返回空列表。slug 家族不在已安装目录中的实时模型会标记为“已知但未启用”并保留在选择器之外；扩展已知家族的 slug 会加入其中；服务端独有的 GPT-6.1 模型以及 GPT-6.2 Astra、Sol 在 pi-ai 跟上之前按已安装的同类角色记录映射。`contextWindowMode` 选择以 `context_window`（`default`）或 `max_context_window`（`extended`）作为上报预算；显式的 `contextWindowOverrides` 仍然优先，覆盖值校验也接受该扩展上限。设置卡片会显示当前来源与时间，并提供手动 **从 ChatGPT 刷新**。对服务端列出的 `gpt-6-sol`、`gpt-6-luna`，插件使用对应 GPT-5.6 变体的工具与推理设置，而不是借用 Astra；即使本地上限表还没有新 slug，显式上下文覆盖值也会以实时 `max_context_window` 校验。

### 提示缓存

每次 Codex 请求都会携带 `prompt_cache_key`，以便 OpenAI 在多个回合间复用已缓存的上下文前缀。该键就是 Harness 会话 ID；请求设置 `cacheRetention: "none"` 会同时抑制该键和缓存。无法获取会话 ID 时，插件改用当前有效的系统提示词（包括 pi-ai 1.4.0 中消息记录的系统段落更新）与首条非空用户消息生成稳定键。仍支持旧版提示词字段；只有系统文本的请求也会生成键，而系统文本与用户文本均为空时不发送键。键不同只会导致提示缓存未命中，不会改变回答。请求体仍保留 `store: false` 和 `include: ["reasoning.encrypted_content"]`。设置 `debugLogPayloadFields: true` 可将每次 Codex 请求的字段名写入插件日志以便验证；它只记录字段名，不记录请求或响应内容，默认关闭。

## 诊断与恢复

### 本地安装诊断

已发布的 Alpha 4.33 在 DSH `0.1.5-rc.1` 上列出或准备 Codex 模型时，可能报 `Cannot read properties of undefined (reading 'get')`。新宿主要求按模型记录错误的索引，旧插件 profile 没有提供。包含 [Issue #178 修复](https://github.com/franksong2702/dsh-codex-connect/issues/178)的构建会初始化该索引；重新授权不能补齐这个字段。请选择与宿主版本完成验证的精确插件版本，不能仅凭属于同一 Alpha 系列判断。

运行 `dsh plugin --profile web exec dsh-codex-connect doctor --json` 可检查本地安装元数据，不会联网。兼容性状态含义：`compatible` 表示符合声明的版本要求，不是行为测试通过；`unverified` 表示包版本超出声明的支持集合；`unknown` 表示缺少必要版本元数据或无法读取；`incompatible` 表示 Node 版本不满足声明的 engine 要求。汇总状态依次优先采用 `incompatible`、`unknown`、`unverified`。任何非 compatible 结果或不安全的凭据文件元数据都会让 doctor 返回 `1`，但这并不授权或建议更改 DSH。

常规更新卡片只检查 Codex Connect 发布版本。插件版本检查成功后最多缓存 24 小时，页面挂载期间每五分钟重试不可用的检查；手动检查会绕过缓存。它不会查询宿主兼容性，也不会建议升级或降级宿主。未列入记录的 DSH/plugin 组合需要验证，不能据此认定无法运行。

### 能力探针

本地能力报告不发送网络请求。本地凭据有效且调用受支持时，`capabilities --probe` 会发送一条固定短请求，并可能消耗额度。`auto-review-probe` 只检查 OAuth reviewer 路由及结构化响应，不验证完整 Harness 审批集成，也不执行被审查的动作；满足前置条件时，它也可能发起请求并消耗额度：

```sh
dsh plugin --profile web exec dsh-codex-connect capabilities --model gpt-5.6-sol --json
dsh plugin --profile web exec dsh-codex-connect capabilities --model gpt-5.6-sol --probe --json
dsh plugin --profile web exec dsh-codex-connect auto-review-probe --json
```

除非传入 `--proxy <http(s)-origin>`，探针使用直连。`--timeout-ms <1..60000>` 可覆盖 30 秒期限。命令不跟随重定向、不重试，把响应限制在 64 KiB，并且不会刷新凭据。每项结果标为 `supported`、`rejected` 或 `unknown`；仅有模型目录条目不能证明账户权限。返回 `0` 表示该命令要求的检查均为可用，`1` 表示至少一项被拒绝，`2` 表示证据未知或调用无效。报告会省略凭据、account id、路径、proxy origin、response id、header 和生成文本。

### 远程浏览器授权

OAuth 路由默认只接受 loopback 浏览器。如果 DSH 运行在可信网络中的另一台设备，请在 DSH 主机上添加浏览器地址栏中的精确 origin：

```sh
dsh plugin --profile web exec dsh-codex-connect trust-origin http://192.168.1.20:3080
dsh plugin --profile web exec dsh-codex-connect trusted-origins
dsh plugin --profile web exec dsh-codex-connect untrust-origin http://192.168.1.20:3080
```

必须包含协议和端口，不能包含路径、query 或 fragment。不要把 OAuth 路由暴露到公网；网络不可信时请使用 SSH tunnel。Web 客户端只显示这些命令，不会自行修改 allowlist。

origin allowlist 只控制访问 DSH 的权限，不会把 OpenAI 跳转到浏览器设备的 localhost 回调转发给 DSH 主机。不转发 1455 端口时，可这样完成当前登录：

1. 在模型或插件账户设置中点击 **授权**（或 **添加账户**），在打开的浏览器标签页中完成批准。
2. 跳转到 `http://localhost:1455/auth/callback` 后，远程浏览器可能显示连接错误。复制**地址栏中的完整 URL**，包括 query string。不要复制初始授权链接，也不要只复制 code。
3. 返回同一个 DSH 账户界面，展开可选的手动回调表单，将 URL 粘贴到回调 URL 输入框并提交。表单默认收起；原有自动回调登录行为不变。
4. 等待账户状态更新。URL 无效不会取消当前登录，可粘贴本次授权的正确回调并重试。若授权过期或已取消，请重新开始，并使用新流程的回调。刷新 DSH 页面后，可点击 **继续授权** 重新加入仍在等待的登录。

回调必须匹配当前流程的 redirect URI 和 OAuth state；仅 code、缺少或不匹配的 state、重复参数及重复使用的回调都会被拒绝。提交使用现有同源／可信 origin 检查以及大小受限的 JSON POST。插件不会访问、记录或持久化粘贴的 URL，提交时会清空输入。token 仍保存在 DSH 主机上。只应粘贴到此专用输入框：URL 包含短期凭据，不能分享至聊天、issue、日志或配置中。网络不可信时请使用 SSH tunnel；手动回调不代表可以安全地公开无认证的 DSH 服务，也不会放宽 origin 策略。

### 迁移与冲突

如果启动报告 `openai-codex` 冲突，请检查有效配置，只移除已经确认的旧 `dsh-codex` bundle 或手动 provider 条目。不要删除凭据或无关 provider。包迁移及 Alpha 4.10 搜索历史修复见 [MIGRATION.md](../MIGRATION.md)。

OAuth 单独保存在 `$DSH_HOME/.openai-codex-auth.json`（默认 `~/.dsh`）；`~/.codex/auth.json` 绝不会被复制或修改。移除包不会删除 OAuth 状态。只有确实要删除凭据时才运行 `logout`。
