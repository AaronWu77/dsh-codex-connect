import { AuthInteraction, Credential, CredentialInfo, CredentialStore, OAuthCredential } from "@earendil-works/pi-ai";
import z from "@deepseek-ai/schemastery";
import { ContextFormed } from "@deepseek-ai/dsh-llm";
import "@deepseek-ai/dsh-tools";
import { Context, Service, Volatile } from "@deepseek-ai/cordis";
import { WebSearchProvider, WebSearchRequest, WebSearchResult } from "@deepseek-ai/dsh-web";
declare module '@deepseek-ai/dsh-llm' {
  interface MessageSourceMap {
    'dsh-codex-connect': {
      kind: 'dsh-codex-connect';
    } & ContextFormed;
  }
}
/** Node-free model catalog contract shared by the Host route and browser card. */
/** Same-origin endpoint exposing the complete Codex model catalog. */
declare const OPENAI_CODEX_MODEL_CATALOG_PATH = "/plugins/dsh-codex-connect/models";
/** Same-origin endpoint exposing where the catalog came from and when it was read. */
declare const OPENAI_CODEX_MODEL_CATALOG_STATUS_PATH = "/plugins/dsh-codex-connect/models/status";
/** Same-origin endpoint forcing one live catalog read through the active account. */
declare const OPENAI_CODEX_MODEL_CATALOG_REFRESH_PATH = "/plugins/dsh-codex-connect/models/refresh";
/**
 * Which catalog layer supplied the live model metadata. The picker never
 * empties: every later layer only replaces fields the earlier one declared.
 */
type OpenAICodexCatalogSource = 'live' | 'cache' | 'cli-cache' | 'bundled';
/**
 * Which server-advertised context window becomes the advertised default
 * budget. `default` uses `context_window`; `extended` uses
 * `max_context_window`, the same ceiling the override validation accepts.
 */
type OpenAICodexContextWindowMode = 'default' | 'extended';
/** One server-advertised service tier for a Codex model. */
interface OpenAICodexModelServiceTier {
  /** Stable server tier id sent as `service_tier`. */
  id: string;
  /** Optional server-provided display name. */
  name?: string;
  /** Optional server-provided description. */
  description?: string;
}
/** One server-advertised reasoning effort accepted by a Codex model. */
interface OpenAICodexModelReasoningLevel {
  /** Effort id accepted by the provider. */
  effort: string;
  /** Optional server-provided description. */
  description?: string;
}
/**
 * Keep unlisted or newer provider defaults usable without inventing a larger
 * limit. A live `max_context_window` is the authoritative ceiling when present;
 * the shipped table only covers installed models the live catalog did not reach.
 * @param id - catalog model id.
 * @param contextWindow - advertised default budget for this model.
 * @param liveMaxContextWindow - server `max_context_window`, when the live catalog declared one.
 * @returns the ceiling accepted by override validation and its provenance.
 */
declare function openAICodexContextLimit(id: string, contextWindow: number, liveMaxContextWindow?: number): {
  maxContextWindow: number;
  contextLimitSource: 'codex-catalog' | 'catalog-default';
};
/** Resolve the advertised budget for one model from the selected context-window mode. */
declare function openAICodexModeContextWindow(defaultWindow: number, extendedWindow: number, mode: OpenAICodexContextWindowMode): number;
/** Where the effective catalog came from and when it was last replaced. */
interface OpenAICodexModelCatalogStatus {
  source: OpenAICodexCatalogSource;
  /** Epoch milliseconds of the last accepted catalog payload; absent when only the bundled catalog answered. */
  updatedAt?: number;
  /** Official client version sent as the `client_version` gate. */
  clientVersion: string;
  /** Number of models in the effective catalog. */
  modelCount: number;
  /** Live slugs whose family the installed catalog does not know; kept out of the picker. */
  unavailableModels: readonly string[];
}
/** Validate the catalog-source status before it enters React state. */
declare function decodeOpenAICodexModelCatalogStatus(value: unknown): OpenAICodexModelCatalogStatus | undefined;
/** Mutually exclusive requested service hints. */
type OpenAICodexSpeedMode = 'standard' | 'fast' | 'ultrafast';
/** Optional profile effort; the current Host validates each model before authentication. */
declare const OPENAI_CODEX_REASONING_EFFORTS: readonly ["off", "minimal", "low", "medium", "high", "xhigh", "max"];
/** Reasoning choices accepted by the current PiAiAdapter profile consumer. */
type OpenAICodexReasoningEffort = typeof OPENAI_CODEX_REASONING_EFFORTS[number];
/** Node-free operator authorization scopes shared by Host settings and Client configuration. */
/** Closed local authorization choices; enabling the remote reviewer does not select a broader scope. */
declare const AUTO_REVIEW_LOCAL_POLICIES: readonly ["manual", "workspace-read", "workspace-files"];
/** Manual has no standing grant; the other values grant only locally eligible ordinary file operations. */
type AutoReviewLocalPolicy = typeof AUTO_REVIEW_LOCAL_POLICIES[number];
/** Pure encoded-image header validation for PNG, JPEG, and WebP. */
type CodexImageMediaType = 'image/png' | 'image/jpeg' | 'image/webp';
/** Bytes must already have passed the caller's session/attachment authorization. */
interface ImageEditInputBytes {
  readonly data: Uint8Array;
  readonly mediaType: CodexImageMediaType;
}
/** A host-only request. Model-visible attachment IDs are never provider file IDs. */
interface ImageEditRequest {
  readonly prompt: string;
  readonly images: readonly ImageEditInputBytes[];
}
type OpenAICodexAccountProfileSource = 'oauth' | 'generated';
/** Maximum number of stored OpenAI Codex accounts. */
declare const OPENAI_CODEX_ACCOUNT_LIMIT = 16;
/** Browser-safe identity shared by Codex account routes and Composer controls. */
/** Primary Harness route and pi-ai provider id owned by this bundle. */
declare const OPENAI_CODEX_PROVIDER = "openai-codex";
/** Basename of the OAuth document inside the Harness home. */
declare const OPENAI_CODEX_AUTH_FILENAME = ".openai-codex-auth.json";
/** Maximum serialized credential document size. */
declare const OPENAI_CODEX_AUTH_DOCUMENT_LIMIT: number;
/** Suffix used for the one-time version-1 rollback copy. */
declare const OPENAI_CODEX_AUTH_V1_BACKUP_SUFFIX = ".v1-backup";
interface OpenAICodexAccountSummary {
  accountKey: string;
  displayName: string;
  maskedEmail?: string;
  profileSource: OpenAICodexAccountProfileSource;
  active: boolean;
}
/** One request's credentials and browser labels from the same document read. */
interface CapturedOpenAICodexAccount extends CredentialStore {
  accounts(): Promise<readonly OpenAICodexAccountSummary[]>;
  captureActiveAccount(): Promise<CapturedOpenAICodexAccount>;
}
/**
 * Resolve the default OAuth document path.
 * @param dshHome - optional Harness-home override.
 * @returns the absolute owner-only document path.
 */
declare function openAICodexAuthPath(dshHome?: string): string;
/** File-backed pi-ai store scoped to the single OpenAI Codex provider. */
declare class OpenAICodexCredentialStore implements CredentialStore {
  /** Absolute credential document path. */
  readonly filename: string;
  /** Owner-only version-1 rollback copy, created at the first migration write. */
  readonly version1BackupFilename: string;
  private readonly changeListeners;
  /**
   * Observe committed credential-document changes that can alter the stored
   * account set or the current selection. Token refreshes of one captured
   * request do not notify. A throwing listener is contained so it cannot fail
   * the commit.
   * @param listener - called after each such change commits.
   * @returns the unsubscribe function.
   */
  onDidChange(listener: () => void): () => void;
  private notifyChanged;
  /**
   * @param filename - explicit document path, defaulting under `$DSH_HOME`.
   */
  constructor(filename?: string);
  /** Read and validate the current document without acquiring the writer lock. */
  private readDocument;
  private readDocumentAt;
  private writeDocument;
  /** @inheritdoc */
  read(providerId: string): Promise<Credential | undefined>;
  /**
   * Capture the current account for one request's complete auth resolution.
   * Refreshes through the returned store update only that captured account and
   * never change the user's current account selection.
   */
  captureActiveAccount(): Promise<CapturedOpenAICodexAccount>;
  /**
   * Capture one exact stored account by its browser-safe key for a request's
   * complete auth resolution, whether or not it is the current selection.
   * Refreshes through the returned store update only that captured account and
   * never change the user's current account selection.
   * @param selectedAccountKey - account key from {@link accounts}.
   * @returns the request-scoped store; an unknown key captures no credential.
   */
  captureAccount(selectedAccountKey: string): Promise<CapturedOpenAICodexAccount>;
  /** Bind one already-read credential to a request-scoped store. */
  private captureCredential;
  private modifyCapturedAccount;
  /** @inheritdoc */
  list(): Promise<readonly CredentialInfo[]>;
  /** List browser-safe account summaries without exposing provider account ids. */
  accounts(): Promise<readonly OpenAICodexAccountSummary[]>;
  /** Resolve the account id stored with one exact access token. */
  accountIdForAccess(access: string): Promise<string | undefined>;
  /** Select a stored account using its browser-safe key. */
  activate(selectedAccountKey: string): Promise<OAuthCredential>;
  /** Remove one account; active removal requires an explicit stored replacement. */
  removeAccount(selectedAccountKey: string, replacementAccountKey?: string): Promise<void>;
  /** @inheritdoc */
  modify(providerId: string, fn: (current: Credential | undefined) => Promise<Credential | undefined>, options?: Parameters<CredentialStore['modify']>[2]): Promise<Credential | undefined>;
  /** @inheritdoc */
  delete(providerId: string): Promise<void>;
  /** Allow the provider's 15-second refresh plus bounded filesystem completion. */
  private withWriterLock;
}
/** Explicit Codex-only HTTP(S) proxying, probing, and lifecycle ownership. */
/** Canonical first-party endpoint used for a no-auth, no-model reachability probe. */
declare const OPENAI_CODEX_PROXY_PROBE_URL = "https://chatgpt.com/backend-api/codex";
/** Upper bound for one candidate probe, including CONNECT and response headers. */
declare const OPENAI_CODEX_PROXY_PROBE_TIMEOUT_MS = 3000;
/** Maximum number of candidates considered by automatic detection. */
declare const OPENAI_CODEX_PROXY_CANDIDATE_LIMIT = 8;
/** Bounded local candidates documented by the settings UI. */
declare const OPENAI_CODEX_LOCAL_PROXY_CANDIDATES: readonly ["http://127.0.0.1:7890", "http://127.0.0.1:7897", "http://127.0.0.1:10809"];
/** Stable probe classifications safe to display in the browser. */
type OpenAICodexProxyProbeClassification = 'reachable' | 'upstream-authentication-required' | 'proxy-authentication-required' | 'dns-failure' | 'connection-refused' | 'timeout' | 'tls-failure' | 'connect-failure' | 'invalid';
/** Result of testing one proxy origin. */
interface OpenAICodexProxyProbeResult {
  /** Canonical proxy origin tested. */
  proxyUrl: string;
  /** Whether the proxy returned any HTTP response from the probe origin. */
  reachable: boolean;
  /** Bounded category for a UI troubleshooting message. */
  classification: OpenAICodexProxyProbeClassification;
  /** Upstream or proxy status, when an HTTP response was received. */
  status?: number;
}
/** Return a small, deterministic candidate set; this never scans LAN hosts or ports. */
declare function listOpenAICodexProxyCandidates(): readonly string[];
/** One plugin instance owns its proxy agents and contributes one global wrapper owner. */
declare class OpenAICodexProxyManager {
  private readonly agents;
  private readonly connections;
  private activeOperations;
  private idleWaiters;
  private disposed;
  private disposePromise;
  private closing;
  private waitForIdle;
  private closeAgents;
  private shutdown;
  private agentFor;
  private acquire;
  /** Run a synchronous or asynchronous Codex operation in the selected proxy scope. */
  run<T>(proxyUrl: string | undefined, operation: () => T): T;
  /** Run a streaming operation and keep the proxy lease until its final event. */
  runStream<T extends {
    result(): Promise<unknown>;
  }>(proxyUrl: string | undefined, operation: () => T): T;
  /** Probe one proxy without credentials, model calls, quota calls, or settings writes. */
  probe(proxyUrl: string, signal?: AbortSignal): Promise<OpenAICodexProxyProbeResult>;
  /** Allow one second to drain, then destroy owned pools with a one-second completion bound. */
  dispose(): Promise<void>;
  /** Bound shutdown as on disposal; reject new proxy leases until reconfiguration finishes. */
  deactivate(): Promise<void>;
}
/** Probe the bounded automatic candidate set in parallel. */
declare function detectOpenAICodexProxies(manager: OpenAICodexProxyManager, signal?: AbortSignal): Promise<readonly OpenAICodexProxyProbeResult[]>;
/** Cordis service name owned by the core plugin fiber. */
declare const OPENAI_CODEX_TRANSPORT_SERVICE = "openaiCodexTransport";
/** Structured contract version used across the core and companion packages. */
declare const OPENAI_CODEX_TRANSPORT_API_VERSION: 1;
/** Stage-zero verified image-generation endpoint. */
declare const OPENAI_CODEX_IMAGE_GENERATION_URL = "https://chatgpt.com/backend-api/codex/images/generations";
/** Network deadline covering the request and bounded response read. */
declare const OPENAI_CODEX_IMAGE_REQUEST_TIMEOUT_MS = 120000;
/** Maximum accepted success-body size: 48 MiB. */
declare const OPENAI_CODEX_IMAGE_MAX_RESPONSE_BYTES: number;
/** Maximum error-body size read and discarded: 64 KiB. */
declare const OPENAI_CODEX_IMAGE_MAX_ERROR_BYTES: number;
/** Defensive upper bound for unexpected multi-image responses. */
declare const OPENAI_CODEX_IMAGE_MAX_COUNT = 4;
/** Local prompt limit enforced before any credential or network work. */
declare const OPENAI_CODEX_IMAGE_PROMPT_MAX_LENGTH = 32000;
/** Stable, secret-free transport errors consumed structurally by companion packages. */
declare const OPENAI_CODEX_TRANSPORT_ERROR_CODES: {
  readonly invalidRequest: "OPENAI_CODEX_INVALID_REQUEST";
  readonly signedOut: "OPENAI_CODEX_SIGNED_OUT";
  readonly reauthRequired: "OPENAI_CODEX_REAUTH_REQUIRED";
  readonly rateLimited: "OPENAI_CODEX_RATE_LIMITED";
  readonly upstreamRejected: "OPENAI_CODEX_UPSTREAM_REJECTED";
  readonly upstreamUnavailable: "OPENAI_CODEX_UPSTREAM_UNAVAILABLE";
  readonly redirectRejected: "OPENAI_CODEX_REDIRECT_REJECTED";
  readonly timeout: "OPENAI_CODEX_TIMEOUT";
  readonly canceled: "OPENAI_CODEX_CANCELED";
  readonly networkError: "OPENAI_CODEX_NETWORK_ERROR";
  readonly responseTooLarge: "OPENAI_CODEX_RESPONSE_TOO_LARGE";
  readonly malformedResponse: "OPENAI_CODEX_MALFORMED_RESPONSE";
};
/** Union of the stable transport error codes. */
type OpenAICodexTransportErrorCode = (typeof OPENAI_CODEX_TRANSPORT_ERROR_CODES)[keyof typeof OPENAI_CODEX_TRANSPORT_ERROR_CODES];
/** Fixed, secret-free transport failure. */
declare class OpenAICodexTransportError extends Error {
  readonly code: OpenAICodexTransportErrorCode;
  readonly status?: number;
  readonly retryAfterSeconds?: number;
  constructor(code: OpenAICodexTransportErrorCode, options?: {
    status?: number;
    retryAfterSeconds?: number;
  });
}
/** Identify transport failures structurally without relying on cross-package class identity. */
declare function isOpenAICodexTransportError(error: unknown): error is OpenAICodexTransportError;
/** Only caller-controlled field accepted by the Host transport. */
interface ImageGenerationRequest {
  readonly prompt: string;
}
/** Request lifecycle supplied by the Host tool in PR-3. */
interface ImageRequestContext {
  /** Captured route account; absence retains the active image-account behavior. */
  readonly accountKey?: string;
  readonly signal?: AbortSignal | undefined;
}
/** One encoded image awaiting PR-3 signature and attachment validation. */
interface GeneratedImagePayload {
  readonly b64Json: string;
}
/** Bounded, structured success projection returned to the companion package. */
interface ImageGenerationResponse {
  readonly apiVersion: 1;
  readonly traceId: string;
  readonly elapsedMs: number;
  readonly responseBytes: number;
  readonly images: readonly GeneratedImagePayload[];
}
/** Versioned Host-only API provided by the core plugin. */
interface OpenAICodexTransportV1 {
  readonly apiVersion: 1;
  /** Optional increment: callers reject edits when absent, without generating. */
  editImages?(input: ImageEditRequest, context: ImageRequestContext): Promise<ImageGenerationResponse>;
  generateImages(input: ImageGenerationRequest, context: ImageRequestContext): Promise<ImageGenerationResponse>;
}
/** Core-owned Cordis service for the optional image package. */
declare class OpenAICodexTransport extends Service implements OpenAICodexTransportV1 {
  private readonly credentials;
  private readonly proxyManager?;
  private readonly resolveProxyUrl;
  private readonly resolveImageModelHint;
  readonly apiVersion: 1;
  private readonly lifetime;
  private readonly pending;
  constructor(ctx: Context, credentials: OpenAICodexCredentialStore, proxyManager?: OpenAICodexProxyManager | undefined, resolveProxyUrl?: () => string | undefined, resolveImageModelHint?: () => string);
  private requestImages;
  generateImages(input: ImageGenerationRequest, context: ImageRequestContext): Promise<ImageGenerationResponse>;
  /** Snapshot authorized image bytes before queueing; one request, no automatic retry. */
  editImages(input: ImageEditRequest, context: ImageRequestContext): Promise<ImageGenerationResponse>;
  private generateImagesWithoutProxy;
}
/** Stable Codex tool name. */
declare const VIEW_IMAGE_TOOL_NAME = "view_image";
/** Stable model-callable tool name. */
declare const IMAGE_GENERATE_TOOL_NAME = "codex_connect_image_generate";
declare const COMPATIBILITY_SCHEMA_VERSION: 1;
declare const SUPPORTED_NODE_RANGE = "^22.19.0 || >=24.0.0";
declare const SUPPORTED_DSH_PLUGIN_API_VERSIONS: readonly ["0.2.2-rc.4"];
declare const SUPPORTED_DSH_PLUGIN_API_VERSION: "0.2.2-rc.4";
declare const SUPPORTED_DSH_PLUGIN_API_RANGE: string;
declare const SUPPORTED_PI_AI_RANGE = "1.4.0";
declare const PI_AI_PACKAGE = "@earendil-works/pi-ai";
declare const DSH_PLUGIN_API_PACKAGES: readonly ["@deepseek-ai/dsh-agent", "@deepseek-ai/dsh-atomic-write", "@deepseek-ai/dsh-attachment", "@deepseek-ai/dsh-home-paths", "@deepseek-ai/dsh-host-webserver", "@deepseek-ai/dsh-llm", "@deepseek-ai/dsh-llm-pi-ai", "@deepseek-ai/dsh-fs", "@deepseek-ai/dsh-session", "@deepseek-ai/dsh-settings", "@deepseek-ai/dsh-tools", "@deepseek-ai/dsh-util-values", "@deepseek-ai/dsh-web"];
declare const COMPATIBILITY_PACKAGES: readonly ["@deepseek-ai/dsh-llm", "@deepseek-ai/dsh-llm-pi-ai", "@earendil-works/pi-ai", "@earendil-works/pi-ai-host"];
type CompatibilityPackageName = (typeof COMPATIBILITY_PACKAGES)[number];
/** Version metadata proves a declared match, not behavioral failure for an untested package. */
type CompatibilityStatus = 'compatible' | 'unverified' | 'incompatible' | 'unknown';
interface CompatibilityEntry {
  supported: string;
  installed: string | null;
  status: CompatibilityStatus;
}
interface CompatibilityReport {
  schemaVersion: typeof COMPATIBILITY_SCHEMA_VERSION;
  status: CompatibilityStatus;
  node: CompatibilityEntry;
  packages: Record<CompatibilityPackageName, CompatibilityEntry>;
}
interface CompatibilityEvaluationInput {
  /** Node version to evaluate; defaults to the running process in detectCompatibility. */
  nodeVersion?: string | null;
  /** Alias accepted by callers that already group installed values. */
  node?: string | null;
  /** Installed package versions keyed by package name. */
  packageVersions?: Partial<Record<CompatibilityPackageName, string | null | undefined>>;
  /** Alias accepted by callers that already group installed values. */
  packages?: Partial<Record<CompatibilityPackageName, string | null | undefined>>;
  /** Nested installed values are useful when feeding a captured diagnostic fixture. */
  installed?: {
    node?: string | null;
    packages?: Partial<Record<CompatibilityPackageName, string | null | undefined>>;
  };
}
interface CompatibilityDetectionOptions extends CompatibilityEvaluationInput {
  /** Test seam for package metadata resolution; no package paths are returned. */
  readPackageVersion?: (name: CompatibilityPackageName) => string | null | undefined | Promise<string | null | undefined>;
}
/** Public contract data mirrored by compatibility.json without importing JSON at runtime. */
declare const COMPATIBILITY_CONTRACT: {
  readonly schemaVersion: 1;
  readonly engines: {
    readonly node: "^22.19.0 || >=24.0.0";
  };
  readonly dshPluginApi: {
    readonly version: "0.2.2-rc.4";
    readonly versions: readonly ["0.2.2-rc.4"];
    readonly packages: readonly ["@deepseek-ai/dsh-agent", "@deepseek-ai/dsh-atomic-write", "@deepseek-ai/dsh-attachment", "@deepseek-ai/dsh-home-paths", "@deepseek-ai/dsh-host-webserver", "@deepseek-ai/dsh-llm", "@deepseek-ai/dsh-llm-pi-ai", "@deepseek-ai/dsh-fs", "@deepseek-ai/dsh-session", "@deepseek-ai/dsh-settings", "@deepseek-ai/dsh-tools", "@deepseek-ai/dsh-util-values", "@deepseek-ai/dsh-web"];
  };
  readonly piAi: {
    readonly package: "@earendil-works/pi-ai";
    readonly version: "1.4.0";
  };
  readonly piAiHost: {
    readonly package: "@earendil-works/pi-ai-host";
    readonly version: "1.4.0";
  };
};
/** Evaluate a captured set of versions without touching the filesystem. */
declare function evaluateCompatibility(input?: CompatibilityEvaluationInput): CompatibilityReport;
/** Alias for callers that prefer assessment terminology. */
declare const assessCompatibility: typeof evaluateCompatibility;
/** Read installed package metadata and return only versions and statuses. */
declare function detectCompatibility(options?: CompatibilityDetectionOptions): Promise<CompatibilityReport>;
/** Inputs that are safe to obtain without booting OAuth. */
interface OpenAICodexDiagnosticOptions {
  /** Credential pathname to inspect through metadata only. */
  credentialPath?: string;
  /** Provider ids already registered in the active Harness context. */
  providerIds?: readonly string[];
  /** Whether the optional standalone search provider is enabled. */
  enableSearch?: boolean;
  /** Whether the optional image tool is enabled. */
  enableImageTool?: boolean;
  /** Whether the optional image generation tool is enabled. */
  enableImageGeneration?: boolean;
  /** Optional pure-function seam for compatibility checks in tests/diagnostic callers. */
  compatibilityOptions?: CompatibilityDetectionOptions;
}
interface OpenAICodexDiagnosticReport {
  package: 'dsh-codex-connect';
  version: string;
  node: string;
  credentialFile: {
    path: string;
    state: 'missing' | 'owner-only' | 'permissions-too-broad' | 'not-a-regular-file' | 'unreadable-metadata';
    mode?: string;
  };
  capabilities: {
    modelProvider: true;
    search: boolean;
    imageTool: boolean;
    imageGeneration: boolean;
    changesHarnessDefaultModel: false;
    changesHarnessSearchRoute: boolean;
  };
  providerConflict: boolean;
  compatibility: CompatibilityReport;
  hints: string[];
}
/** Actionable message for legacy/manual `openai-codex` adapter collisions. */
declare function openAICodexConflictMessage(): string;
/** Fail before the generic registry error so the collision has a migration hint. */
declare function assertNoOpenAICodexProviderConflict(providerIds: readonly string[]): void;
/**
 * Inspect only process and filesystem metadata. This function never opens the
 * OAuth document, refreshes a token, or starts an authorization flow.
 */
declare function diagnoseOpenAICodex(options?: OpenAICodexDiagnosticOptions): Promise<OpenAICodexDiagnosticReport>;
/** Fixed endpoint used by the official Codex client for ChatGPT rate limits. */
declare const OPENAI_CODEX_USAGE_URL = "https://chatgpt.com/backend-api/wham/usage";
/** One quota window expressed as remaining capacity for direct UI rendering. */
interface OpenAICodexRateLimitWindow {
  /** Percent still available in this window. */
  readonly remainingPercent: number;
  /** Server-declared rolling-window length in seconds. */
  readonly windowSeconds: number;
  /** Server-declared reset time as Unix seconds, when supplied and valid. */
  readonly resetAt?: number;
}
/** One separately metered Codex quota bucket. */
interface OpenAICodexRateLimit {
  /** Stable server feature id. */
  readonly id: string;
  /** Optional server-provided display name. */
  readonly name?: string;
  /** Available rolling windows for this bucket. */
  readonly windows: readonly OpenAICodexRateLimitWindow[];
}
/** Optional exact prepaid-credit balance returned by ChatGPT. */
interface OpenAICodexCredits {
  /** Whether the balance is unmetered. */
  readonly unlimited: boolean;
  /** Exact provider-formatted balance when finite and disclosed. */
  readonly balance?: string;
}
/** One ChatGPT rate-limit reset card reported for an account. */
interface OpenAICodexResetCredit {
  /** Server-supplied card id. */
  readonly id: string;
  /** Server reset category, for example `codex_rate_limits`. */
  readonly resetType: string;
  /** Server card status, for example `available`. */
  readonly status: string;
  /** Server grant time as Unix seconds. */
  readonly grantedAt: number;
  /** Server expiry time as Unix seconds; absent when the card does not expire. */
  readonly expiresAt?: number;
  /** Optional server-provided display title. */
  readonly title?: string;
}
/** Reset cards reported for one account. */
interface OpenAICodexResetCredits {
  /** Count the server reports as available. */
  readonly availableCount: number;
  /** Reported cards, when the server lists them. */
  readonly credits?: readonly OpenAICodexResetCredit[];
}
/** Optional exact workspace member spend limit returned by ChatGPT. */
interface OpenAICodexIndividualLimit {
  /** Exact configured limit. */
  readonly limit: string;
  /** Exact amount consumed. */
  readonly used: string;
  /** Exact amount still available. */
  readonly remaining: string;
  /** Percent still available for progress rendering. */
  readonly remainingPercent: number;
}
/** Secret-free quota projection returned to the browser. */
interface OpenAICodexUsage {
  /** Rolling Codex rate-limit buckets. */
  readonly rateLimits: readonly OpenAICodexRateLimit[];
  /** Exact prepaid-credit balance when supported for this account. */
  readonly credits?: OpenAICodexCredits;
  /** Exact workspace member limit when supported for this account. */
  readonly individualLimit?: OpenAICodexIndividualLimit;
  /** Rate-limit reset cards when the endpoint reports them. */
  readonly resetCredits?: OpenAICodexResetCredits;
}
/**
 * Convert the provider response into the small secret-free object sent to the browser.
 * @param value - opaque JSON returned by the ChatGPT usage endpoint.
 * @returns core and additionally metered quota buckets with remaining percentages,
 *   plus the optional reset-credit block.
 */
declare function parseOpenAICodexUsage(value: unknown): OpenAICodexUsage;
/**
 * Read current quota without issuing a model request. OAuth is refreshed through
 * the same provider-native credential lifecycle used by normal Codex turns.
 * @param store - plugin-owned OAuth credential store.
 * @returns current rate-limit buckets safe to expose to the local browser page.
 */
declare function readOpenAICodexRateLimits(store: Pick<OpenAICodexCredentialStore, 'captureActiveAccount'>, cancellation?: AbortSignal): Promise<OpenAICodexUsage>;
/** Stable Harness settings namespace owned by this plugin. */
declare const OPENAI_CODEX_SETTINGS_NAMESPACE = "llm-openai-codex";
/**
 * Official client version the model catalog endpoint requires. The endpoint is
 * version-gated: a recent official value returns the full catalog, older
 * values return an empty list, and omitting it fails with HTTP 400. Override
 * only to follow a newer official client.
 */
declare const DEFAULT_OPENAI_CODEX_MODEL_CATALOG_CLIENT_VERSION = "0.155.0";
/** Default context-window mode: the server's default budget, not its extended ceiling. */
declare const DEFAULT_OPENAI_CODEX_CONTEXT_WINDOW_MODE: "default";
/** Whether a value is a bounded official-client version sent as `client_version`. */
declare function isValidOpenAICodexModelCatalogClientVersion(value: unknown): value is string;
/** Suggested local HTTP proxy shown by the settings UI; it is never enabled by default. */
declare const DEFAULT_OPENAI_CODEX_PROXY_URL = "http://127.0.0.1:7890";
/** Empty profile setting, which makes image requests use the default route hint. */
declare const DEFAULT_OPENAI_CODEX_IMAGE_MODEL_HINT = "";
/** Validate an optional bounded ASCII image route model hint. */
declare function isValidOpenAICodexImageModelHint(value: unknown): value is string;
/** Whether a value is a supported, canonical HTTP(S) proxy origin. */
declare function isValidOpenAICodexProxyUrl(value: unknown): value is string;
/** Search modes accepted by the Codex standalone search endpoint. */
type OpenAICodexSearchMode = 'cached' | 'indexed' | 'live';
/** Search-context sizes accepted by the Codex standalone search endpoint. */
type OpenAICodexSearchContextSize = 'low' | 'medium' | 'high';
/** Whether a value is a bounded per-model context-window override map. */
declare function isValidOpenAICodexContextWindowOverrides(value: unknown): value is Readonly<Record<string, number | null>>;
/** Whether a value is a bounded per-model maximum-output-token override map. */
declare function isValidOpenAICodexMaxTokensOverrides(value: unknown): value is Readonly<Record<string, number | null>>;
/** Default model used by the standalone search endpoint. */
declare const DEFAULT_OPENAI_CODEX_SEARCH_MODEL = "gpt-5.6-sol";
/** Default search mode, matching the official local Codex client. */
declare const DEFAULT_OPENAI_CODEX_SEARCH_MODE: OpenAICodexSearchMode;
/** Default provider search-context size. */
declare const DEFAULT_OPENAI_CODEX_SEARCH_CONTEXT_SIZE: OpenAICodexSearchContextSize;
/** Default output budget for the standalone search response. */
declare const DEFAULT_OPENAI_CODEX_SEARCH_MAX_OUTPUT_TOKENS = 10000;
/**
 * Codex model transport. `sse` keeps finite response streams, `auto` opens a
 * request-owned WebSocket per request, and `websocket-cached` keeps one
 * resident connection per admitted conversation so consecutive turns can
 * continue through `previous_response_id`.
 */
type OpenAICodexModelTransport = 'sse' | 'auto' | 'websocket-cached';
/** Fully resolved user-editable section presented by Plugin configuration. */
interface OpenAICodexSettingsConfig {
  /**
   * Explicit model transport; undefined lets {@link maxResidentWebSocketSessions}
   * decide, and `auto` keeps request-owned WebSocket connections without reuse.
   */
  transport?: OpenAICodexModelTransport | undefined;
  /**
   * Resident continuation connections kept open for conversation turns. Each
   * admitted conversation holds one connection while it stays active; title,
   * compaction, Auto-review, and subagent requests always use SSE. 0 disables
   * continuation entirely.
   */
  maxResidentWebSocketSessions: number;
  /** Model ids advertised in selectors; undefined advertises the full catalog. */
  models: string[] | undefined;
  /** Route Codex Connect requests through the explicitly configured proxy. */
  enableProxy: boolean;
  /** Credential-free HTTP(S) proxy origin; inactive while enableProxy is false. */
  proxyUrl: string;
  /**
   * Per-model context-window overrides keyed by catalog model id. Each value
   * replaces the advertised `contextWindow` for that model inside the adapter
   * profile for client budgeting. It does not change or verify server capacity,
   * output-token limits, or the deployment's compaction policy.
   */
  contextWindowOverrides: Readonly<Record<string, number>> | undefined;
  /**
   * Per-model maximum output tokens keyed by catalog model id. Each value sets
   * the request default output cap DSH reports for that model and the resolved
   * model record's `maxTokens`. It does not change the context window or the
   * provider's actual capability.
   */
  maxTokensOverrides: Readonly<Record<string, number>> | undefined;
  /**
   * Which server-advertised window becomes the advertised budget. "default"
   * uses the live catalog's `context_window`; "extended" uses its
   * `max_context_window`, the same ceiling override validation accepts.
   * An explicit per-model `contextWindowOverrides` entry still wins.
   */
  contextWindowMode: OpenAICodexContextWindowMode;
  /** Official client version sent as the model catalog's `client_version` gate. */
  modelCatalogClientVersion: string;
  /**
   * Log the payload field names of each Codex request. Development-only: it
   * records field names, never payload content, and the default is off.
   */
  debugLogPayloadFields: boolean;
  enableNewSessionFastMode: boolean;
  enableNewSubagentFastMode: boolean;
  newSessionSpeedMode: OpenAICodexSpeedMode | undefined;
  newSubagentSpeedMode: OpenAICodexSpeedMode | undefined;
  reasoningEffort: OpenAICodexReasoningEffort | undefined;
  enableSearch: boolean;
  enableImageTool: boolean;
  enableImageGeneration: boolean;
  /** Optional profile-scoped model hint for image generation; empty uses the route default. */
  imageModelHint: string;
  /** Whether this profile accepted the Auto-review data disclosure. */
  autoReviewDisclosureAcknowledged: boolean;
  /** Let the hidden Codex reviewer answer eligible DSH approval requests. */
  enableAutoReview: boolean;
  /** Explicit local standing scope; remote model advice never grants authority. */
  autoReviewLocalPolicy: AutoReviewLocalPolicy;
  searchModel: string;
  searchMode: OpenAICodexSearchMode;
  searchContextSize: OpenAICodexSearchContextSize;
  searchMaxOutputTokens: number;
}
declare const DEFAULT_OPENAI_CODEX_SETTINGS: Readonly<OpenAICodexSettingsConfig>;
/** Input settings allow null to disable overrides inherited from a lower settings layer. */
interface OpenAICodexSettingsInput extends Partial<Omit<OpenAICodexSettingsConfig, 'contextWindowOverrides' | 'maxTokensOverrides' | 'newSessionSpeedMode' | 'newSubagentSpeedMode' | 'reasoningEffort'>> {
  newSessionSpeedMode?: OpenAICodexSpeedMode | null | undefined;
  newSubagentSpeedMode?: OpenAICodexSpeedMode | null | undefined;
  reasoningEffort?: OpenAICodexReasoningEffort | null | undefined;
  contextWindowOverrides?: Readonly<Record<string, number | null>> | null | undefined;
  maxTokensOverrides?: Readonly<Record<string, number | null>> | null | undefined;
}
/** Fill the schema defaults even when called without Cordis validation. */
declare function resolveOpenAICodexSettings(value: OpenAICodexSettingsInput): OpenAICodexSettingsConfig;
/** Resolve the active proxy without treating a disabled value as a route. */
declare function resolveOpenAICodexProxyUrl(value: OpenAICodexSettingsInput): string | undefined;
/** Narrow the redacted settings wire payload before it enters React state. */
declare function decodeOpenAICodexSettings(value: unknown): OpenAICodexSettingsConfig | undefined;
/** Stable provider id listed in official Web Search settings. */
declare const OPENAI_CODEX_SEARCH_PROVIDER = "openai-codex";
/** Trusted first-party Codex base; OAuth credentials never cross to a configured origin. */
declare const OPENAI_CODEX_BASE_URL = "https://chatgpt.com/backend-api/codex";
/** Standalone search endpoint used by the official Codex client. */
declare const OPENAI_CODEX_SEARCH_URL = "https://chatgpt.com/backend-api/codex/alpha/search";
interface SearchRequestBody {
  readonly id: string;
  readonly model: string;
  readonly input: readonly [{
    readonly type: 'message';
    readonly role: 'user';
    readonly content: readonly [{
      readonly type: 'input_text';
      readonly text: string;
    }];
  }];
  readonly commands: {
    readonly search_query: readonly [{
      readonly q: string;
    }];
  };
  readonly settings: {
    readonly search_context_size: OpenAICodexSearchContextSize;
    readonly allowed_callers: readonly ['direct'];
    readonly external_web_access: boolean | 'indexed';
  };
  readonly max_output_tokens: number;
}
/** Exact secret-free request recorded before a standalone search dispatch. */
interface OpenAICodexSearchRequestRecord {
  /** Fixed first-party endpoint. */
  readonly endpoint: typeof OPENAI_CODEX_SEARCH_URL;
  /** Exact JSON body sent to the provider. */
  readonly body: SearchRequestBody;
}
/** Fully resolved provider options. */
interface OpenAICodexSearchProviderOptions {
  /** Shared persistent OAuth store. */
  readonly credentials: OpenAICodexCredentialStore;
  /** Model sent to the standalone search endpoint. */
  readonly model: string;
  /** Cached, indexed, or live external-web policy. */
  readonly mode: OpenAICodexSearchMode;
  /** Provider-side search context size. */
  readonly contextSize: OpenAICodexSearchContextSize;
  /** Upper bound on the standalone endpoint's generated output. */
  readonly maxOutputTokens: number;
  /** Resolve the request identity, normally the initiating session id. */
  readonly resolveRequestId: () => string;
  /** Owns the request-scoped dispatcher when a custom proxy is active. */
  readonly proxyManager?: OpenAICodexProxyManager;
  /** Resolve the active proxy for each search request. */
  readonly resolveProxyUrl?: () => string | undefined;
  /** Record the exact secret-free request before dispatch. */
  readonly recordRequest?: (request: OpenAICodexSearchRequestRecord) => void;
}
/**
 * Map the standalone endpoint's forward-compatible result DTOs into the dsh
 * web result. Unknown DTO types and fields are ignored; malformed envelope
 * fields fail at the network boundary.
 * @param value - parsed response JSON.
 * @returns normalized answer and citeable sources.
 */
declare function mapOpenAICodexSearchResponse(value: unknown): WebSearchResult;
/** OpenAI Codex standalone-search provider using the same refreshable OAuth store as the LLM route. */
declare class OpenAICodexSearchProvider implements WebSearchProvider {
  private readonly options;
  readonly id = "openai-codex";
  readonly title = "OpenAI Codex";
  /**
   * @param options - fixed trusted endpoint policy and deployment tunables.
   */
  constructor(options: OpenAICodexSearchProviderOptions);
  /** The local configuration is usable; credential presence is resolved per request. */
  available(): boolean;
  /** @inheritdoc */
  search(request: WebSearchRequest, signal?: AbortSignal): Promise<WebSearchResult>;
  private searchWithoutProxy;
}
/** Fixed endpoint the official Codex client reads its model catalog from. */
declare const OPENAI_CODEX_MODELS_URL = "https://chatgpt.com/backend-api/codex/models";
/** Plugin-owned cache basename inside the Harness home. */
declare const OPENAI_CODEX_MODEL_CATALOG_CACHE_FILENAME = "dsh-codex-connect-models.json";
/** How long an accepted catalog read suppresses the next live read. */
declare const OPENAI_CODEX_MODEL_CATALOG_TTL_MS: number;
/** One server-advertised Codex model. */
interface OpenAICodexLiveModel {
  /** Server model slug, matched against the installed catalog id. */
  slug: string;
  /** Optional server display name. */
  displayName?: string;
  /** Optional server description. */
  description?: string;
  /** Optional server default reasoning effort. */
  defaultReasoningLevel?: string;
  /** Server-advertised reasoning efforts. */
  reasoningLevels: readonly OpenAICodexModelReasoningLevel[];
  /** Server default context window in tokens. */
  contextWindow: number;
  /** Server extended context ceiling in tokens; equals `contextWindow` when omitted. */
  maxContextWindow: number;
  /** Server maximum output tokens when the model declares one. */
  maxOutputTokens?: number;
  /** Server-advertised service tiers. */
  serviceTiers: readonly OpenAICodexModelServiceTier[];
  /** Server input modalities when the model declares them. */
  inputModalities: readonly string[];
  /**
   * True when the last accepted read for this account no longer advertised the model.
   * The entry keeps resolving, so surfaces can explain the change instead of dropping it.
   */
  withdrawn?: true;
}
/** Host dependencies of the catalog service. */
interface OpenAICodexModelCatalogOptions {
  /** Owns the stored accounts and the request-scoped credential capture. */
  credentials: Pick<OpenAICodexCredentialStore, 'accounts' | 'captureAccount' | 'captureActiveAccount'>;
  /** Plugin-owned cache file path under the Harness home. */
  cachePath: string;
  /** Official client version sent as the `client_version` gate. */
  clientVersion: string;
  /** Owns Codex-only proxy dispatch; absent uses the direct connection. */
  proxyManager?: OpenAICodexProxyManager | undefined;
  /** Resolve the explicitly activated proxy for each read. */
  resolveProxyUrl?: (() => string | undefined) | undefined;
  /** Codex CLI cache path; defaults to `$CODEX_HOME/models_cache.json`. */
  cliCachePath?: string | undefined;
  /** Override the HTTP implementation in tests. */
  fetchImpl?: typeof fetch | undefined;
  /** Monotonic clock override in tests. */
  now?: (() => number) | undefined;
  /** Structured logger for the once-per-streak failure report. */
  logError?: ((message: string, error?: unknown) => void) | undefined;
}
/** One resolved view of the catalog plus where it came from. */
interface OpenAICodexCatalogSnapshot {
  source: OpenAICodexCatalogSource;
  updatedAt?: number;
  etag?: string;
  models: readonly OpenAICodexLiveModel[];
}
/**
 * Decode the catalog payload shared by the live endpoint and the Codex CLI cache.
 * @param value - parsed JSON body.
 * @returns every decodable model, in server order.
 */
declare function parseOpenAICodexModelsPayload(value: unknown): OpenAICodexLiveModel[];
/** Resolve the Codex CLI cache path without writing anything under it. */
declare function openAICodexCliModelCachePath(): string;
declare class OpenAICodexModelCatalog {
  private readonly options;
  private readonly layers;
  private activeAccountKey;
  private revisionCounter;
  private failureLogged;
  private inflight;
  private disposed;
  private readonly lifetime;
  private clientVersion;
  /**
   * @param options - credential store, cache path, and optional proxy and clock overrides.
   */
  constructor(options: OpenAICodexModelCatalogOptions);
  /** Follow a settings change; a different gate invalidates every account's TTL. */
  setClientVersion(value: string): void;
  /** Monotonic identity of the current layer; profile caches key on it. */
  get revision(): number;
  /** The current selection's effective live-model layer; empty means the bundled catalog answers. */
  models(): readonly OpenAICodexLiveModel[];
  /**
   * One stored account's effective live-model layer. An account with no accepted read
   * answers with nothing, so its route falls back to the bundled catalog instead of
   * advertising another account's entitlement list.
   * @param accountKey - browser-safe account key from the credential store.
   * @returns that account's server-advertised models.
   */
  modelsFor(accountKey: string | undefined): readonly OpenAICodexLiveModel[];
  /** @param accountKey - Stored account, or the current account when omitted. @returns The accepted catalog source. */
  source(accountKey?: string): OpenAICodexCatalogSource;
  /** @param accountKey - Stored account, or the current account when omitted. @returns Accepted-payload epoch milliseconds, or undefined for bundled-only metadata. */
  updatedAt(accountKey?: string): number | undefined;
  /** Load the plugin cache file, then start one live read per stored account when stale. */
  initialize(): Promise<void>;
  /** Whether the current account's layer is still inside the TTL. */
  isFresh(): boolean;
  /** Stop accepting further reads; the current layers stay readable. */
  dispose(): Promise<void>;
  /** The layer key answering for the current selection; empty until an account is known. */
  private layerKey;
  /** Resolve the stored account the primary route currently authenticates as. */
  private readActiveAccountKey;
  /**
   * Read every stored account's live catalog unless fresh layers exist, coalescing callers.
   * Never rejects: a failed account read keeps that account's previous layer and is logged
   * once per failure streak.
   * @param force - bypass the TTL, as the manual refresh affordance does.
   */
  refresh(force?: boolean, cancellation?: AbortSignal): Promise<void>;
  private now;
  /** Publish one account's layer at the point its read settled. */
  private setLayer;
  private logFailure;
  private runRefresh;
  /** Read one account's catalog as that exact account; a failure keeps its previous layer. */
  private refreshAccount;
  /** Second fallback: the official client's own cache, read but never written. */
  private fallbackToCliCache;
  private requestUrl;
  private requestHeaders;
  private readCacheFile;
  /** Decode one stored layer; a malformed layer reads as absent. */
  private cachedSnapshot;
  private writeCacheFile;
}
/** Node-free route constants shared by the Host and browser plugin halves. */
/** Detect bounded local/environment proxy candidates without changing settings. */
declare const OPENAI_CODEX_PROXY_DETECT_PATH = "/plugins/dsh-openai-codex/proxy/detect";
/** Test one manually entered proxy origin without changing settings. */
declare const OPENAI_CODEX_PROXY_TEST_PATH = "/plugins/dsh-openai-codex/proxy/test";
/** Non-secret login state shown by the launcher. */
interface OpenAICodexAuthStatus {
  /** Whether a stored OAuth credential exists. */
  authenticated: boolean;
  /** Access-token expiry time; refresh is automatic on the next request. */
  expiresAt?: Date;
}
/**
 * Complete provider-native OAuth and persist the resulting credential.
 * @param interaction - terminal or UI callbacks for the provider flow.
 * @param store - credential store, defaulting under `$DSH_HOME`.
 */
declare function loginOpenAICodex(interaction: AuthInteraction, store?: OpenAICodexCredentialStore): Promise<void>;
/**
 * Remove the stored OpenAI Codex credential.
 * @param store - credential store, defaulting under `$DSH_HOME`.
 */
declare function logoutOpenAICodex(store?: OpenAICodexCredentialStore): Promise<void>;
/**
 * Read non-secret OpenAI Codex login state without refreshing the token.
 * @param store - credential store, defaulting under `$DSH_HOME`.
 * @returns stored login state and expiry.
 */
declare function openAICodexAuthStatus(store?: CredentialStore): Promise<OpenAICodexAuthStatus>;
/** Process-local, per-session OpenAI Codex Fast Mode state. */
/** Maximum number of enabled sessions retained by one plugin instance. */
declare const OPENAI_CODEX_FAST_MODE_MAX_SESSIONS = 256;
/** Maximum UTF-16 code units accepted for an opaque DSH session id. */
declare const OPENAI_CODEX_FAST_MODE_MAX_SESSION_ID_LENGTH = 256;
/**
 * Validate the opaque session identity used by the Fast Mode registry.
 *
 * The registry deliberately does not interpret or normalize session ids.  It
 * only rejects values that cannot safely serve as a bounded map key.
 */
declare function isFastModeSessionId(value: unknown): value is string;
/**
 * In-memory Fast Mode registry.  Entries are positive-only: disabling a
 * session removes its key, and an insertion over the bound evicts the least
 * recently touched key.  A new plugin instance starts with an empty map.
 */
declare class FastModeRegistry {
  private readonly maxSessions;
  private readonly enabledSessions;
  constructor(maxSessions?: number);
  /** Number of currently enabled sessions. */
  get size(): number;
  /** Read one session without exposing the map or any credential state. */
  isEnabled(sessionId: unknown): boolean;
  /** Alias useful to callers that model this as a boolean setting. */
  get(sessionId: unknown): boolean;
  /** Enable or disable exactly one opaque session id. */
  set(sessionId: unknown, enabled: boolean): void;
  /** Explicitly named alias for callers that avoid boolean-setting verbs. */
  setEnabled(sessionId: unknown, enabled: boolean): void;
  /** Disable one session and forget its key. */
  delete(sessionId: unknown): void;
  /** Remove all process-local state during an explicit lifecycle teardown. */
  clear(): void;
}
/** Node-free Fast Mode route constants shared by Host and browser halves. */
/** GET/POST endpoint for one conversation's process-local Fast Mode state. */
declare const OPENAI_CODEX_FAST_MODE_PATH = "/plugins/dsh-openai-codex/fast-mode";
interface ParsedVersion {
  major: number;
  minor: number;
  patch: number;
  prerelease: Array<number | string>;
}
/** Parse one exact package version, accepting the conventional leading `v`. */
declare function parseOpenAICodexVersion(raw: string): ParsedVersion | undefined;
/** Compare two package versions using SemVer precedence (build metadata ignored). */
declare function compareOpenAICodexVersions(left: string, right: string): number;
/** Offline compatibility migration for the private Codex search event emitted by Alpha 4.10. */
/** Private event written by Alpha 4.10 before the provider stopped persisting it. */
declare const OPENAI_CODEX_SEARCH_MODEL_REQUEST_EVENT = "web/openai-codex-search-llm-request";
/** Backup suffix created beside every changed session artifact. */
declare const OPENAI_CODEX_HISTORY_BACKUP_SUFFIX = ".pre-codex-search-history-migration";
interface OpenAICodexHistoryMigrationOptions {
  /** Apply changes; omitted/false performs a read-only dry run. */
  readonly apply?: boolean;
  /** Required acknowledgement that every DSH writer using this root is stopped. */
  readonly confirmStopped?: boolean;
  /** Explicit JSONL persistence root. Defaults to `<DSH_HOME>/sessions`. */
  readonly root?: string;
  /** Optional Harness home override used only when `root` is omitted. */
  readonly dshHome?: string;
}
interface OpenAICodexHistoryMigrationFile {
  readonly path: string;
  readonly changedEvents: number;
  readonly backupPath?: string;
}
interface OpenAICodexHistoryMigrationResult {
  readonly mode: 'apply' | 'dry-run';
  readonly root: string;
  readonly changedFiles: number;
  readonly changedEvents: number;
  readonly files: readonly OpenAICodexHistoryMigrationFile[];
}
/**
 * Mark the retired Alpha 4.10 search event ignorable in compressed JSONL logs.
 * Applying is an offline maintenance operation and fails closed without the
 * caller's explicit acknowledgement that all DSH writers are stopped.
 */
declare function migrateOpenAICodexSearchHistory(options?: OpenAICodexHistoryMigrationOptions): Promise<OpenAICodexHistoryMigrationResult>;
declare module '@deepseek-ai/cordis' {
  interface Context {
    /** Host-only image transport owned by the Codex Connect core fiber. */
    openaiCodexTransport: OpenAICodexTransportV1;
  }
}
/** Stable Cordis plugin name. */
declare const name = "llm-openai-codex";
/** The model registry required before the provider can register. */
declare const inject: string[];
/** Branded Host settings namespace for Codex Connect capability configuration. */
declare const OPENAI_CODEX_SETTINGS_NS = "llm-openai-codex";
/** Composite model and standalone-search configuration. */
interface Config {
  /**
   * Explicit model transport. Omitted derives it from
   * {@link maxResidentWebSocketSessions}: `websocket-cached` for a positive
   * budget, SSE otherwise. `auto` keeps request-owned WebSocket connections
   * only at budget 0; a positive budget overrides `auto`, so that combination
   * is rejected at load.
   */
  transport?: OpenAICodexModelTransport | undefined;
  /**
   * Resident continuation connections kept open for conversation turns;
   * 0 disables continuation. Title, compaction, Auto-review, and subagent
   * requests always use SSE, so they never consume a slot.
   */
  maxResidentWebSocketSessions?: number;
  /** Complete interactive OAuth deadline in milliseconds; applies when the plugin loads. */
  oauthTimeoutMs?: number;
  /** Model ids advertised in selectors; omitted to advertise the full catalog. */
  models?: string[] | undefined;
  /** Route Codex Connect requests through proxyUrl after explicit activation. */
  enableProxy?: boolean;
  /** Credential-free HTTP(S) proxy origin. */
  proxyUrl?: string;
  /**
   * Per-model context-window overrides keyed by catalog model id. Each value
   * replaces the advertised `contextWindow` for that model inside the adapter
   * profile for client budgeting. It does not change or verify server capacity,
   * output-token limits, or the deployment's compaction policy.
   * Whole-map or per-model null disables inherited overrides; omitted keys inherit lower layers.
   */
  contextWindowOverrides?: Record<string, number | null> | null | undefined;
  /**
   * Per-model maximum output tokens keyed by catalog model id. Each value sets
   * the request default output cap DSH reports for that model and the resolved
   * model record's `maxTokens`. It does not change the context window, the
   * provider's actual capability, or the deployment's compaction policy.
   * Whole-map or per-model null disables inherited overrides; omitted keys inherit lower layers.
   */
  maxTokensOverrides?: Record<string, number | null> | null | undefined;
  /**
   * Which server-advertised context window becomes the advertised budget.
   * "default" uses the live catalog's `context_window`; "extended" uses its
   * `max_context_window`. An explicit `contextWindowOverrides` entry still wins.
   */
  contextWindowMode?: OpenAICodexContextWindowMode;
  /**
   * Official client version sent as the model catalog's `client_version` gate.
   * The endpoint rejects an omitted value and returns an empty list for one
   * below the client's floor, so this stays a known-good default.
   */
  modelCatalogClientVersion?: string;
  /**
   * Log the payload field names of each Codex request. Development-only: it
   * writes field names, never payload content, and is off by default.
   */
  debugLogPayloadFields?: boolean;
  enableNewSessionFastMode?: boolean;
  enableNewSubagentFastMode?: boolean;
  newSessionSpeedMode?: OpenAICodexSpeedMode | null | undefined;
  newSubagentSpeedMode?: OpenAICodexSpeedMode | null | undefined;
  reasoningEffort?: OpenAICodexReasoningEffort | null | undefined;
  /** Register the optional standalone Codex search provider. */
  enableSearch?: boolean;
  /** Register the optional image-loading tool. */
  enableImageTool?: boolean;
  /** Register the optional prompt-only image generation tool. */
  enableImageGeneration?: boolean;
  /** Optional profile-scoped image route model hint; empty uses the default route hint. */
  imageModelHint?: string;
  /** Record that this profile accepted the Auto-review data disclosure. */
  autoReviewDisclosureAcknowledged?: boolean;
  /** Let the hidden Codex reviewer answer eligible DSH approval requests. */
  enableAutoReview?: boolean;
  autoReviewLocalPolicy?: AutoReviewLocalPolicy;
  /** IANA time zone for local Session usage days; defaults to the Host time zone. */
  localUsageTimeZone?: string;
  /** Number of populated local usage days retained per Session. */
  localUsageRetainedDays?: number;
  /** Client observation interval for the on-demand usage warm-up, in milliseconds. */
  localUsagePollMs?: number;
  /** Pause between two stored-log reads during the warm-up, in milliseconds. */
  localUsageRestMs?: number;
  /** Model used for auxiliary standalone searches. */
  searchModel?: string;
  /** Cached, indexed, or live web access. */
  searchMode?: OpenAICodexSearchMode;
  /** Amount of search context returned by the provider. */
  searchContextSize?: OpenAICodexSearchContextSize;
  /** Maximum generated tokens returned by the standalone search endpoint. */
  searchMaxOutputTokens?: number;
}
/** Runtime configuration exposes each editable field through Cordis's public Volatile type. */
interface VolatileConfig {
  transport: Volatile<OpenAICodexModelTransport | undefined>;
  maxResidentWebSocketSessions: Volatile<number>;
  oauthTimeoutMs: number;
  models: Volatile<string[] | undefined>;
  enableProxy: Volatile<boolean>;
  proxyUrl: Volatile<string>;
  contextWindowOverrides: Volatile<Readonly<Record<string, number | null>> | null | undefined>;
  maxTokensOverrides: Volatile<Readonly<Record<string, number | null>> | null | undefined>;
  contextWindowMode: Volatile<OpenAICodexContextWindowMode>;
  modelCatalogClientVersion: Volatile<string>;
  debugLogPayloadFields: Volatile<boolean>;
  enableNewSessionFastMode: Volatile<boolean>;
  enableNewSubagentFastMode: Volatile<boolean>;
  newSessionSpeedMode: Volatile<OpenAICodexSpeedMode | null | undefined>;
  newSubagentSpeedMode: Volatile<OpenAICodexSpeedMode | null | undefined>;
  reasoningEffort: Volatile<OpenAICodexReasoningEffort | null | undefined>;
  enableSearch: Volatile<boolean>;
  enableImageTool: Volatile<boolean>;
  enableImageGeneration: Volatile<boolean>;
  imageModelHint: Volatile<string>;
  autoReviewDisclosureAcknowledged: Volatile<boolean>;
  enableAutoReview: Volatile<boolean>;
  autoReviewLocalPolicy: Volatile<AutoReviewLocalPolicy>;
  localUsageTimeZone: string;
  localUsageRetainedDays: number;
  localUsagePollMs: number;
  localUsageRestMs: number;
  searchModel: Volatile<string>;
  searchMode: Volatile<OpenAICodexSearchMode>;
  searchContextSize: Volatile<OpenAICodexSearchContextSize>;
  searchMaxOutputTokens: Volatile<number>;
}
declare const Config: z<Config, VolatileConfig>;
/**
 * Register the `openai-codex` LLM route with one provider-native OAuth store.
 * Search and image tooling are added only when their config flags are true.
 * Selecting this route as the Harness default remains a separate profile choice.
 * @param ctx - plugin context carrying the LLM registry plus optional services.
 * @param config - capability gates and standalone-search tuning.
 */
declare function apply(ctx: Context, config: Config | VolatileConfig): void;
export { COMPATIBILITY_CONTRACT, COMPATIBILITY_PACKAGES, COMPATIBILITY_SCHEMA_VERSION, type CompatibilityDetectionOptions, type CompatibilityEntry, type CompatibilityEvaluationInput, type CompatibilityPackageName, type CompatibilityReport, type CompatibilityStatus, Config, DEFAULT_OPENAI_CODEX_CONTEXT_WINDOW_MODE, DEFAULT_OPENAI_CODEX_IMAGE_MODEL_HINT, DEFAULT_OPENAI_CODEX_MODEL_CATALOG_CLIENT_VERSION, DEFAULT_OPENAI_CODEX_PROXY_URL, DEFAULT_OPENAI_CODEX_SEARCH_CONTEXT_SIZE, DEFAULT_OPENAI_CODEX_SEARCH_MAX_OUTPUT_TOKENS, DEFAULT_OPENAI_CODEX_SEARCH_MODE, DEFAULT_OPENAI_CODEX_SEARCH_MODEL, DEFAULT_OPENAI_CODEX_SETTINGS, DSH_PLUGIN_API_PACKAGES, FastModeRegistry, FastModeRegistry as OpenAICodexFastModeRegistry, type GeneratedImagePayload, IMAGE_GENERATE_TOOL_NAME, type ImageGenerationRequest, type ImageGenerationResponse, type ImageRequestContext, OPENAI_CODEX_ACCOUNT_LIMIT, OPENAI_CODEX_AUTH_DOCUMENT_LIMIT, OPENAI_CODEX_AUTH_FILENAME, OPENAI_CODEX_AUTH_V1_BACKUP_SUFFIX, OPENAI_CODEX_BASE_URL, OPENAI_CODEX_FAST_MODE_MAX_SESSIONS, OPENAI_CODEX_FAST_MODE_MAX_SESSION_ID_LENGTH, OPENAI_CODEX_FAST_MODE_PATH, OPENAI_CODEX_HISTORY_BACKUP_SUFFIX, OPENAI_CODEX_IMAGE_GENERATION_URL, OPENAI_CODEX_IMAGE_MAX_COUNT, OPENAI_CODEX_IMAGE_MAX_ERROR_BYTES, OPENAI_CODEX_IMAGE_MAX_RESPONSE_BYTES, OPENAI_CODEX_IMAGE_PROMPT_MAX_LENGTH, OPENAI_CODEX_IMAGE_REQUEST_TIMEOUT_MS, OPENAI_CODEX_LOCAL_PROXY_CANDIDATES, OPENAI_CODEX_MODELS_URL, OPENAI_CODEX_MODEL_CATALOG_CACHE_FILENAME, OPENAI_CODEX_MODEL_CATALOG_PATH, OPENAI_CODEX_MODEL_CATALOG_REFRESH_PATH, OPENAI_CODEX_MODEL_CATALOG_STATUS_PATH, OPENAI_CODEX_MODEL_CATALOG_TTL_MS, OPENAI_CODEX_PROVIDER, OPENAI_CODEX_PROXY_CANDIDATE_LIMIT, OPENAI_CODEX_PROXY_DETECT_PATH, OPENAI_CODEX_PROXY_PROBE_TIMEOUT_MS, OPENAI_CODEX_PROXY_PROBE_URL, OPENAI_CODEX_PROXY_TEST_PATH, OPENAI_CODEX_SEARCH_MODEL_REQUEST_EVENT, OPENAI_CODEX_SEARCH_PROVIDER, OPENAI_CODEX_SEARCH_URL, OPENAI_CODEX_SETTINGS_NAMESPACE, OPENAI_CODEX_SETTINGS_NS, OPENAI_CODEX_TRANSPORT_API_VERSION, OPENAI_CODEX_TRANSPORT_ERROR_CODES, OPENAI_CODEX_TRANSPORT_SERVICE, OPENAI_CODEX_USAGE_URL, type OpenAICodexAccountSummary, type OpenAICodexAuthStatus, type OpenAICodexCatalogSnapshot, type OpenAICodexCatalogSource, type OpenAICodexContextWindowMode, OpenAICodexCredentialStore, type OpenAICodexCredits, type OpenAICodexDiagnosticOptions, type OpenAICodexDiagnosticReport, type OpenAICodexHistoryMigrationFile, type OpenAICodexHistoryMigrationOptions, type OpenAICodexHistoryMigrationResult, type OpenAICodexIndividualLimit, type OpenAICodexLiveModel, OpenAICodexModelCatalog, type OpenAICodexModelCatalogOptions, type OpenAICodexModelCatalogStatus, type OpenAICodexModelReasoningLevel, type OpenAICodexModelServiceTier, OpenAICodexProxyManager, type OpenAICodexProxyProbeClassification, type OpenAICodexProxyProbeResult, type OpenAICodexRateLimit, type OpenAICodexRateLimitWindow, type OpenAICodexSearchContextSize, type OpenAICodexSearchMode, OpenAICodexSearchProvider, type OpenAICodexSearchProviderOptions, type OpenAICodexSearchRequestRecord, type OpenAICodexSettingsConfig, OpenAICodexTransport, OpenAICodexTransportError, type OpenAICodexTransportErrorCode, type OpenAICodexTransportV1, type OpenAICodexUsage, PI_AI_PACKAGE, SUPPORTED_DSH_PLUGIN_API_RANGE, SUPPORTED_DSH_PLUGIN_API_VERSION, SUPPORTED_DSH_PLUGIN_API_VERSIONS, SUPPORTED_NODE_RANGE, SUPPORTED_PI_AI_RANGE, VIEW_IMAGE_TOOL_NAME, VolatileConfig, apply, assertNoOpenAICodexProviderConflict, assessCompatibility, compareOpenAICodexVersions, decodeOpenAICodexModelCatalogStatus, decodeOpenAICodexSettings, detectCompatibility, detectOpenAICodexProxies, diagnoseOpenAICodex, evaluateCompatibility, inject, isFastModeSessionId, isOpenAICodexTransportError, isValidOpenAICodexContextWindowOverrides, isValidOpenAICodexImageModelHint, isValidOpenAICodexMaxTokensOverrides, isValidOpenAICodexModelCatalogClientVersion, isValidOpenAICodexProxyUrl, listOpenAICodexProxyCandidates, loginOpenAICodex, logoutOpenAICodex, mapOpenAICodexSearchResponse, migrateOpenAICodexSearchHistory, name, openAICodexAuthPath, openAICodexAuthStatus, openAICodexCliModelCachePath, openAICodexConflictMessage, openAICodexContextLimit, openAICodexModeContextWindow, parseOpenAICodexModelsPayload, parseOpenAICodexUsage, parseOpenAICodexVersion, readOpenAICodexRateLimits, resolveOpenAICodexProxyUrl, resolveOpenAICodexSettings };