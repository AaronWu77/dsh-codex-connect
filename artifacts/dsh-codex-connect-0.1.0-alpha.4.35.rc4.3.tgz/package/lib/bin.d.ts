/** Standalone credential CLI for the optional OpenAI Codex bundle. */
/** Execute one boot-free credential command. */
declare function run(argv: readonly string[]): Promise<number>;
export { run };